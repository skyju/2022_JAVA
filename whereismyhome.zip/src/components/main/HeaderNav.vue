<template>
  <header>
    <div class="header-top">
      <div class="header-btns">
        <template v-if="userInfo == 'admin'">
          <router-link :to="`/user/list`">
            <button id="btn-mv-list" class="btn btn-outline-primary btn-sm">
              회원목록
            </button>
          </router-link>
        </template>
        <!--after login-->
        <template v-if="userInfo">
          <button id="logout-btn" @click.prevent="onClickLogout">Logout</button>
          <router-link :to="{ name: 'mypage' }">
            <button id="userinfo-btn">회원정보</button>
          </router-link>
        </template>
        <!--before login-->
        <template v-else>
          <router-link :to="{ name: 'join' }">
            <button id="signup-btn"><i class="fas fa-user"></i>Sign Up</button>
          </router-link>
          <button id="login-btn" @click="clickLoginBtn">
            <i class="fas fa-lock"></i>Login
          </button>
        </template>
      </div>
    </div>

    <b-form id="form-loign-window" method="POST" action="/user/login">
      <input type="hidden" name="act" value="login" />
      <div :class="isNone ? 'display-none' : 'login-window'" :key="isNone">
        <div>
          <div>아 이 디</div>
          <input type="text" name="userid" id="login-window-id" />
        </div>
        <div>
          <div>비밀번호</div>
          <input type="password" name="userpwd" id="login-window-pw" />
        </div>
        <div class="login-btns">
          <input type id="login-window-login" vlaue="로 그 인" />
        </div>
      </div>
    </b-form>

    <div class="header-bottom">
      <router-link to="/">
        <div class="header-bottom-left">
          <img src="@/assets/home_logo.png" alt="logo" />
        </div>
      </router-link>
      <div class="header-bottom-right">
        <b-nav tabs class="header-nav-list">
          <template v-if="userInfo">
            <b-nav-item>
              <router-link to="/interest/list"> 관심 지역 </router-link>
            </b-nav-item>
          </template>
          <b-nav-item>
            <router-link to="/board/list"> QnA 게시판 </router-link>
          </b-nav-item>
          <b-nav-item Disabled>오늘의 뉴스</b-nav-item>
        </b-nav>
      </div>
    </div>
  </header>
</template>

<script>
import { mapState, mapGetters, mapActions } from "vuex";

const memberStore = "memberStore";

export default {
  name: "HeaderNav",
  data() {
    return {
      isNone: true,
    };
  },
  computed: {
    ...mapState(memberStore, ["isLogin", "userInfo"]),
    ...mapGetters(["checkUserInfo"]),
  },
  methods: {
    goIndexPage() {
      this.$router.push("/");
    },
    clickLoginBtn() {
      if (this.isNone === true) {
        this.isNone = false;
      } else {
        this.isNone = true;
      }
    },
    ...mapActions(memberStore, ["userLogout"]),
    // ...mapMutations(memberStore, ["SET_IS_LOGIN", "SET_USER_INFO"]),
    onClickLogout() {
      // this.SET_IS_LOGIN(false);
      // this.SET_USER_INFO(null);
      // sessionStorage.removeItem("access-token");
      // if (this.$route.path != "/") this.$router.push({ name: "main" });
      console.log(this.userInfo.userid);
      //vuex actions에서 userLogout 실행(Backend에 저장 된 리프레시 토큰 없애기
      //+ satate에 isLogin, userInfo 정보 변경)
      // this.$store.dispatch("userLogout", this.userInfo.userid);
      this.userLogout(this.userInfo.userid);
      sessionStorage.removeItem("access-token"); //저장된 토큰 없애기
      sessionStorage.removeItem("refresh-token"); //저장된 토큰 없애기
      if (this.$route.path != "/") this.$router.push({ name: "main" });
    },
  },
};
</script>
<style>
.display-none {
  display: none;
}
header {
  display: flex;
  flex-direction: column;
  flex: 1.5;
}
.header-top {
  background-color: #222;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  padding: 5px 50px;
}
.header-btns button svg {
  margin-right: 5px;
}
.header-btns button {
  background-color: #333;
  border: none;
  color: #fff;
  padding: 5px;
  border-radius: 3px;
  cursor: pointer;
}
.header-bottom {
  padding: 15px 50px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.header-bottom-left {
  flex: 1;
}
.header-bottom-left img {
  width: 100px;
  cursor: pointer;
}
.header-bottom-right > ul {
  display: flex;
}
.header-bottom-right > ul li {
  margin-left: 50px;
  cursor: pointer;
}
.login-window {
  position: absolute;
  /* z-index: 1; */
  top: 35px;
  right: 50px;
  width: 250px;
  height: 270px;
  background-color: #222;
  display: flex;
  flex-direction: column;
  justify-content: center;
  /* align-items: center; */
  padding: 25px;
  color: #fff;
  font-size: 13px;
}
.login-window input {
  width: 200px;
  height: 35px;
  margin: 10px 0;
  padding-left: 10px;
  color: #fff;
  background-color: #444;
  border: 2px solid rgb(46, 45, 45);
  border-radius: 3px;
}
.login-btns {
  position: relative;
  left: 0;
  display: flex;
  flex-direction: column;
}
.login-window button {
  width: fit-content;
  padding: 5px 12px;
  margin-bottom: 15px;
  border-radius: 3px;
  border: 1.5px solid #222;
  cursor: pointer;
}
.login-window button:nth-child(2) {
  background-color: #333;
  color: #fff;
  border: 1.5px solid #222;
}
div.item {
  border-style: solid;
  border-width: 2px;
}
#signup-btn {
  margin-right: 7px;
}
#logout-btn {
  margin-right: 7px;
}
#userinfo-btn.deactive,
#signup-btn.deactive,
#login-btn.deactive,
#logout-btn.deactive {
  display: none;
}
.header-nav-list a {
  text-decoration: none;
  color: black;
}
</style>
