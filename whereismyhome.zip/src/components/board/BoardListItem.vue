<template>
  <tr :class="article.userId == 'admin' ? 'background-color-green' : ''">
    <td>{{ article.articleNo }}</td>
    <td>
      <router-link :to="`/board/view/${article.articleNo}`">
        {{ article.subject }}
      </router-link>
    </td>
    <td style="font-weight: bold">{{ article.userId }}</td>
    <td>{{ article.hit }}</td>
    <td>{{ article.registerTime }}</td>
  </tr>
</template>

<script>
export default {
  name: "BoardListItem",
  props: {
    article: Object,
  },
};
</script>

<style scoped>
.background-color-green {
  background-color: #dff0d8;
}
a {
  color: #0076c0;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}
.board tr:not(.background-color-green):nth-child(even) {
  background-color: #f9f9f9;
}
</style>
