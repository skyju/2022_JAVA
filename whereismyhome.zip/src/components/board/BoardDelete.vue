<template>
  <div class="regist header-h1"></div>
</template>

<script>
import http from "@/api/lib/http";

export default {
  name: "BoardDelete",
  created() {
    // 비동기
    // TODO : 글번호에 해당하는 글을 삭제.
    http.delete(`/board/${this.$route.params.articleno}`).then(({ data }) => {
      let msg = "삭제 처리 중 문제 발생";
      if (data === "success") msg = "삭제에 성공했습니다.";
      alert(msg);
      this.$router.push({ name: "boardlist" });
    });
  },
};
</script>
