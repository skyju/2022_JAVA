<template>
  <div class="regist">
    <div class="header-h1">
      <h1 class="underline">Q & A 글 상세보기</h1>
    </div>
    <div class="regist_form">
      <label> 글번호</label>
      <div class="view">{{ article.articleNo }}</div>
      <label> 글제목</label>
      <div class="view">{{ article.subject }}</div>
      <label> 작성자</label>
      <div class="view">{{ article.userId }}</div>
      <label> 조회수</label>
      <div class="view">{{ article.hit }}</div>
      <label> 작성시간</label>
      <div class="view">{{ article.registerTime }}</div>
      <label> 내용</label>
      <div class="view">{{ article.content }}</div>

      <div style="padding-top: 15px">
        <router-link
          :to="{
            name: 'boardmodify',
            params: { articleNo: article.articleNo },
          }"
        >
          <b-button variant="success">수정</b-button>
        </router-link>
        <router-link
          :to="{
            name: 'boarddelete',
            params: { articleNo: article.articleNo },
          }"
          ><b-button variant="danger">삭제</b-button></router-link
        >
        <router-link :to="{ name: 'boardlist' }" class="btn"
          ><b-button variant="primary">목록</b-button></router-link
        >
      </div>
    </div>
  </div>
</template>

<script>
import http from "@/api/lib/http";

export default {
  name: "BoardView",
  data() {
    return {
      article: Object,
    };
  },
  created() {
    // 비동기
    // TODO : 글번호에 해당하는 글정보 얻기.
    http.get(`/board/view/${this.$route.params.articleno}`).then(({ data }) => {
      this.article = data;
    });
  },
};
</script>
