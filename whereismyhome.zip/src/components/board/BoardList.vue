<template>
  <div class="board-box">
    <div class="board-nav">
      <div class="board-nav-tap">
        <b-nav pills>
          <b-nav-item @click="totalList" :active="active"> 전체 </b-nav-item>
          <b-nav-item @click="moveAdminList" :active="!active">
            공지
          </b-nav-item>
          <b-nav-form @submit.prevent="searchList">
            <b-form-select
              v-model="key"
              :options="options"
              class="form-select nav-select"
            ></b-form-select>
            <b-form-input
              v-model="word"
              aria-label="Input"
              class="mr-1 nav-input"
            ></b-form-input>
            <b-button type="submit" style="width: 60px">검색</b-button>
          </b-nav-form>
        </b-nav>
      </div>
      <b-button variant="primary" @click="moveWrite">글작성</b-button>
    </div>
    <div v-if="articles.length" class="list-body">
      <table id="article-list">
        <colgroup>
          <col style="width: 5%" />
          <col style="width: 65%" />
          <col style="width: 10%" />
          <col style="width: 5%" />
          <col style="width: 15%" />
        </colgroup>
        <thead>
          <tr>
            <th>번호</th>
            <th>제목</th>
            <th>글쓴이</th>
            <th>조회수</th>
            <th>작성일</th>
          </tr>
        </thead>
        <tbody>
          <board-list-item
            v-for="article in articles"
            :key="article.articleno"
            :article="article"
          ></board-list-item>
        </tbody>
      </table>
      <div class="overflow-auto pagination-bar">
        <b-pagination-nav
          :number-of-pages="numOfPage"
          :base-url="`/board/list/${key}/${word}/`"
        ></b-pagination-nav>
      </div>
    </div>

    <div class="text-center" v-else>게시글이 없습니다.</div>
  </div>
</template>

<script>
import BoardListItem from "@/components/board/BoardListItem";
import http from "@/api/lib/http";

export default {
  name: "BoardList",
  components: {
    BoardListItem,
  },
  data() {
    return {
      perPage: 15,
      numOfPage: 1,
      key: null,
      word: null,
      active: true,
      options: [
        { value: null, text: "전체" },
        { value: "subject", text: "제목" },
        { value: "userid", text: "작성자" },
      ],
      articles: [],
      pgno: 1,
    };
  },
  created() {
    let paramPgno = this.$route.params.pgno;
    let paramKey = this.$route.params.key;
    let paramWord = this.$route.params.word;
    if (paramPgno != null && paramPgno != "" && paramPgno != undefined) {
      this.pgno = Number(paramPgno);
    }
    if (paramKey != null && paramKey != "null" && paramKey != undefined) {
      this.key = paramKey;
    }
    if (paramWord != null && paramWord != "null" && paramWord != undefined) {
      this.word = paramWord;
    }
    // 비동기
    // TODO : 글목록 얻기.
    http
      .get(`/board/${this.pgno}/${this.key}/${this.word}`)
      .then(({ data }) => {
        this.articles = data.list;
        this.numOfPage = data.pageNavigation.totalPageCount;
      });
  },
  methods: {
    moveWrite() {
      this.$router.push({ name: "boardwrite" });
    },
    totalList() {
      http
        .get(`/board/${this.pgno}/${this.key}/${this.word}`)
        .then(({ data }) => {
          this.articles = data.list;
          this.numOfPage = data.pageNavigation.totalPageCount;
        });
      this.active = true;
    },
    moveAdminList() {
      http
        .get(`/board/${this.pgno}/${this.key}/${this.word}`, {
          params: { notice: true },
        })
        .then(({ data }) => {
          this.articles = data.list;
          this.numOfPage = data.pageNavigation.totalPageCount;
        });
      this.active = false;
    },
    searchList() {
      http.get(`/board/1/${this.key}/${this.word}`).then(({ data }) => {
        this.articles = data.list;
        this.numOfPage = data.pageNavigation.totalPageCount;
      });
      this.active = true;
    },
  },
};
</script>

<style scoped>
.nav {
  align-items: center;
}
.board-nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.nav-input {
  width: 180px;
  margin-left: 10px;
  height: 35.5px;
  margin-left: 10px;
}
.list-body {
  display: flex;
  flex-direction: column;
  align-items: center;
}
.pagination-bar {
  margin-top: 25px;
  margin-bottom: 25px;
}
</style>
