<template>
  <div id="app">
    <nav>
      <header-nav></header-nav>
      <router-view></router-view>
    </nav>
  </div>
</template>

<script>
import HeaderNav from "./components/main/HeaderNav.vue";

export default {
  components: { HeaderNav },
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  list-style: none;
}
body {
  display: flex;
  flex-direction: column;
}
</style>
