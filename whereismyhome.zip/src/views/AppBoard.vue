<template>
  <div class="board">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: "AppBoard",
};
</script>

<style scope>
.board {
  display: flex;
  justify-content: center;
}
.board .header-h1 {
  display: flex;
  justify-content: center;
  font-size: 20px;
}
.board .underline {
  display: inline-block;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0) 70%, cyan 30%);
}
.board input,
.board textarea,
.board .view {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  color: #787878;
  font-size: medium;
}
.board label {
  display: inline-block;
  width: 80px;
}
.board button,
.board .btn {
  margin: 8px 10px;
  cursor: pointer;
}
#article-list {
  border-collapse: collapse;
  width: 100%;
}
#article-list thead {
  background-color: white;
  font-weight: bold;
}
#article-list td,
#article-list th {
  text-align: center;
  border: 1px solid #ddd;
  border-collapse: collapse;
  height: 50px;
}
.board .regist {
  padding: 10px;
}
.board .regist_form {
  text-align: left;
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}
.board {
  font-size: 13px;
}
.board-box {
  min-width: 800px;
}
.board button {
  margin-bottom: 11px;
  width: 80px;
  height: 35.5px;
  font-size: var(--bs-nav-link-font-size);
  font-weight: var(--bs-nav-link-font-weight);
}
.board select {
  width: 90px;
  display: inline;
  font-size: 13px;
  height: 35.5px;
  margin: 0;
  margin-left: 10px;
}
</style>
