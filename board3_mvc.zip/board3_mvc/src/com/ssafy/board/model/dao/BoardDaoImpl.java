package com.ssafy.board.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ssafy.board.model.BoardDto;
import com.ssafy.member.model.dao.MemberDao;
import com.ssafy.member.model.dao.MemberDaoImpl;
import com.ssafy.util.DBUtil;

public class BoardDaoImpl implements BoardDao {

	private static BoardDao boardDao = new BoardDaoImpl();
	private DBUtil dbUtil;
	private MemberDao memberDao;
	
	private BoardDaoImpl() {
		dbUtil = DBUtil.getInstance();
		memberDao = MemberDaoImpl.getMemberDao();
	}

	public static BoardDao getBoardDao() {
		return boardDao;
	}
	
	@Override
	public int writeArticle(BoardDto boardDto) throws SQLException {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dbUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into `ssafyweb`.`board` \n");
			sql.append("(user_id, subject, content) \n");
			sql.append("values (?, ?, ?)");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, boardDto.getUserId());
			pstmt.setString(2, boardDto.getSubject());
			pstmt.setString(3, boardDto.getContent());
			cnt = pstmt.executeUpdate();
		} finally {
			dbUtil.close(pstmt, conn);
		}
		return cnt;
	}

	@Override
	public List<BoardDto> listArticle(Map<String, String> map) throws SQLException {
		// String 두개는,, 검색어, 페이지 .. 일단 무시하고 구현
		
		List<BoardDto> list = new ArrayList<>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = dbUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * from `ssafyweb`.`board` \n");
			// sql.append("where subject like "%?%" \n");
			// sql.append("where subject like "%?%");
			sql.append("order by article_no desc");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BoardDto info = new BoardDto();
				info.setArticleNo(rs.getInt(1));
				info.setUserId(rs.getString(2));
				info.setUserName(memberDao.getMemberNameById(rs.getString(2)));
				info.setSubject(rs.getString(3));
				info.setContent(rs.getString(4));
				info.setHit(rs.getInt(5));
				info.setRegisterTime(rs.getString(6));
				list.add(info);
			}
		} finally {
			dbUtil.close(rs, pstmt, conn);
		}
		return list;
	}

	@Override
	public int totalArticleCount(Map<String, String> map) throws SQLException {
		return 0;
	}

	@Override
	public BoardDto getArticle(int articleNo) throws SQLException {
		BoardDto article = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = dbUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select * from `ssafyweb`.`board` \n");
			sql.append("where article_no = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, articleNo);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				article = new BoardDto();
				article.setArticleNo(rs.getInt(1));
				article.setUserId(rs.getString(2));
				article.setUserName(memberDao.getMemberNameById(rs.getString(2)));
				article.setSubject(rs.getString(3));
				article.setContent(rs.getString(4));
				article.setHit(rs.getInt(5));
				article.setRegisterTime(rs.getString(6));
			}
		} finally {
			dbUtil.close(rs, pstmt, conn);
		}
		return article;
	}

	@Override
	public void updateHit(int articleNo) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dbUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("update board \n");
			sql.append("set hit = (select hit from \n");
			sql.append(" 	(select hit from board where article_no = ?) a) + 1\n"); 
			sql.append("where article_no = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, articleNo);
			pstmt.setInt(2, articleNo);
			pstmt.executeUpdate();
		} finally {
			dbUtil.close(pstmt, conn);
		}
	}

	@Override
	public void modifyArticle(BoardDto boardDto) throws SQLException {
		
	}

	@Override
	public void deleteArticle(int articleNo) throws SQLException {
		
	}

}
