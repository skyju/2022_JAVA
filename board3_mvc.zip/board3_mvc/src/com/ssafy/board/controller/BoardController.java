package com.ssafy.board.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.board.model.BoardDto;
import com.ssafy.board.model.service.BoardService;
import com.ssafy.board.model.service.BoardServiceImpl;
import com.ssafy.member.model.MemberDto;

@WebServlet("/board")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private BoardService boardService;
	private Map<String, String> map;
	
	public void init() {
		boardService = BoardServiceImpl.getBoardService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act = request.getParameter("act");
		System.out.println("act ==== " + act);
		
		String path = "/index.jsp";
		if("list".equals(act)) {
			path = list(request, response);
			forward(request, response, path);
		} else if("mvwrite".equals(act)) {
			path = "/board/write.jsp";
			redirect(request, response, path);
		} else if("write".equals(act)) {
			path = write(request, response);
			forward(request, response, path);
		} else if("view".equals(act)) {
			path = view(request, response);
			forward(request, response, path);
		} else if("mvmodify".equals(act)) {
			path = mvModify(request, response);
			forward(request, response, path);
		} else if("modify".equals(act)) {
			path = modify(request, response);
			forward(request, response, path);
		} else if("delete".equals(act)) {
			path = delete(request, response);
			redirect(request, response, path);
		} else {
			redirect(request, response,path);
		}
	}
	
	private void forward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher(path);
		dispatcher.forward(request, response);
	}
	
	private void redirect(HttpServletRequest request, HttpServletResponse response, String path) throws IOException {
		response.sendRedirect(request.getContextPath() + path);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}
	
	//////////////////////////////////////////////////////////
	private String list(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<BoardDto> list = boardService.listArticle(map);
			request.setAttribute("articles", list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "/board/list.jsp";
	}

	private String write(HttpServletRequest request, HttpServletResponse response) {
		BoardDto boardDto = new BoardDto();
		
		// 게시글 정보
		boardDto.setSubject(request.getParameter("subject"));
		boardDto.setContent(request.getParameter("content"));
		
		// 작성자 정보
		HttpSession session = request.getSession();
		MemberDto writer = null;
		Object obj = session.getAttribute("loginMember");
		if (obj != null && obj instanceof MemberDto) {
			writer = (MemberDto) session.getAttribute("loginMember");
			boardDto.setUserId(writer.getUserId());
			try {
				boardService.writeArticle(boardDto);
				request.setAttribute("writed", "ok");
			} catch (Exception e) {
				e.printStackTrace();
				return "/error/error.jsp";
			}
		}
		return "/board/result.jsp";
	}
	
	private String view(HttpServletRequest request, HttpServletResponse response) {
		try {
			int articleNo = Integer.parseInt(request.getParameter("articleNo"));
			BoardDto article = boardService.getArticle(articleNo);
			boardService.updateHit(articleNo);
			request.setAttribute("article", article);
		} catch (Exception e) {
			e.printStackTrace();
			return "/error/error.jsp";
		}
		return "/board/view.jsp";
	}

	private String mvModify(HttpServletRequest request, HttpServletResponse response) {
		try {
			int articleNo = Integer.parseInt(request.getParameter("articleno"));
			BoardDto article = boardService.getArticle(articleNo);
			
			// 글의 주인인지 확인하기
			HttpSession session = request.getSession();
			Object obj = session.getAttribute("loginMember");
			MemberDto login = (MemberDto) obj;
			if (login.getUserId().equals(article.getUserId())) {
				request.setAttribute("article", article);
				System.out.println("!!");
			} else { // 권한 없음
				return "/board?act=list";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "/error/error.jsp";
		}
		return "/board/modify.jsp";
	}

	private String modify(HttpServletRequest request, HttpServletResponse response) {
		return "";
	}

	private String delete(HttpServletRequest request, HttpServletResponse response) {
		return "";
	}
	
}
