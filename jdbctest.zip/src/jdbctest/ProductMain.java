package jdbctest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;

import BeanData.ProductDAO;
import BeanData.ProductDAOImpl;
import BeanData.ProductDTO;
import jdbctest.util.CloseUtil;
import jdbctest.util.ConnectionProvider;

public class ProductMain {
	
	protected static Connection con = ConnectionProvider.getConnection();
	protected static ProductDAO productDao = ProductDAOImpl.getProductDao();
	static BufferedReader br;
	public ProductMain() {
		br = new BufferedReader(new InputStreamReader(System.in));
	}
	public static void main(String[] args) throws Exception {
		new ProductMain().menu();
	}

	private void menu() throws Exception {
		boolean isContinue = true;
		while (isContinue) {
			System.out.println("============ 메뉴 선택 ============");
			System.out.println("1. 등록");
			System.out.println("2. 가격 변경");
			System.out.println("3. 제품 삭제");
			System.out.println("4. 아이디로 검색");
			System.out.println("5. 가격으로 검색 (~원 이상)");
			System.out.println("6. 모든 상품 검색");
			System.out.println("0. 종료");
			System.out.println("================================");
			System.out.print("메뉴를 선택하세요: ");
			int num = Integer.parseInt(br.readLine());
			switch (num) {
			case 1: register(); break;
			case 2: updatePrice(); break;
			case 3: deleteByName(); break;
			case 4: selectById(); break;
			case 5: selectByPrice(); break;
			case 6: selectAll(); break;
			default: CloseUtil.close(con); isContinue = false;
			}
		}
	} //end of menu

	private void selectAll() {
		System.out.println("====== 상품 조회 ======");
		productDao.selectAll(con);
		System.out.println("====================");
	}

	private void selectById() throws IOException {
		System.out.println("====== 상품 조회 ======");
		System.out.print("조회할 상품 아이디: ");
		String productId = br.readLine();
		productDao.selectById(con, productId);
		System.out.println("====================");
	}

	private void selectByPrice() throws IOException {
		System.out.println("====== 상품 조회 ======");
		System.out.print("얼마 이상을 찾으십니까?: ");
		int limitPrice = Integer.parseInt(br.readLine());
		productDao.selectByPrice(con, limitPrice);
		System.out.println("====================");
	}

	private void deleteByName() throws IOException {
		System.out.println("====== 상품 삭제 ======");
		System.out.print("삭제하실 상품 명: ");
		String productName = br.readLine();
		productDao.deleteByName(con, productName);
		System.out.println("====================");
	}

	private void updatePrice() throws IOException {
		System.out.println("====== 상품 변경 ======");
		System.out.print("가격을 변경할 상품 아이디: ");
		String productId = br.readLine();
		System.out.print("변경할 가격: ");
		int newPrice = Integer.parseInt(br.readLine());
		productDao.updatePrice(con, productId, newPrice);
		System.out.println("====================");
	}

	private void register() throws Exception {
		System.out.println("====== 상품 등록 ======");
		System.out.print("상품 아이디: ");
		String productId = br.readLine();
		System.out.print("상품 이름: ");
		String productName = br.readLine();
		System.out.print("상품 가격: ");
		int productPrice = Integer.parseInt(br.readLine());
		System.out.print("상품 설명: ");
		String productDesc = br.readLine();
		
		ProductDTO productDto = new ProductDTO(productId, productName, productPrice, productDesc);
		productDao.register(con, productDto);
		
		System.out.println("==== 상품 등록 완료 ====");
	}
}
