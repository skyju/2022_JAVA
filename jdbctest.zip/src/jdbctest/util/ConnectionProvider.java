package jdbctest.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionProvider {
	
	private static String Driver = "com.mysql.cj.jdbc.Driver";
	public static Connection getConnection() {
		try {
			Class.forName(Driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String URL = "jdbc:mysql://localhost:3306/ssafydb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8";
		String DB_ID = "ssafy";
		String DB_PW = "ssafy";
		
		Connection con = null;
		try {
			con = DriverManager.getConnection(URL, DB_ID, DB_PW);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}