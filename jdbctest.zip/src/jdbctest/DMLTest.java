package jdbctest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jdbctest.util.CloseUtil;
import jdbctest.util.ConnectionProvider;

public class DMLTest {

	/*
	 * JDBC 작업순서
	 * 1. Driver Loading
	 * 2. DB 연결 (Connection 생성)
	 * 3. SQL 실행 준비
	 *   3-1. SQL 작성.
	 *   3-2. Statement 생성 (Statement, PreparedStatement)
	 * 4. SQL 실행
	 *   4-1. I, U, D
	 *      int x = stmt.execteUpdate(sql);
	 *   	int x = pstmt.executeUpdate();
	 *   4-2. S
	 *      ResultSet rs = pstmt.executeQuery();
	 *      rs.next() [단독, if, while]
	 *      값 얻기 : rs.getString()
	 *            rs.getInt() 등등등....
	 * 5. DB 연결 종료 : finally, AutoCloseable, try-with-resource (JDK7이상)
	 * 	if(rs != null)
	 *    		rs.close()
	 *  	if(pstmt != null)
	 *  		pstmt.close();
	 *  	if(conn != null)
	 *  		conn.close();
	 */

//	** Driver download : https://dev.mysql.com/downloads/connector/j/
//
//	*** DB 정보
//	driver ==> com.mysql.cj.jdbc.Driver
//	url ==> jdbc:mysql://127.0.0.1:3306/ssafydb?serverTimezone=UTC&useUniCode=yes&characterEncoding=UTF-8
//
//	test table ==>
//
//	create table product
//	(
//	    idx int not null auto_increment,
//	    product_id varchar(7) not null,
//	    product_name varchar(20) not null,
//	    product_price int default 0,
//	    product_desc varchar(2000),
//	    register_date timestamp not null default current_timestamp,
//	    primary key (idx)
//	);
//
//	select product_name, product_id, product_price, product_desc
//		, date_format(register_date, "%y.%m.%d") as date_format
//	from product;
//
//	insert into product (product_id, product_name, product_price, product_desc)
//	values(20020, '가지', 3000, '너무해');
//
//	update product
//	set product_price = 3000000
//	where idx = 1;
//
//	delete from product where idx = 2;
	
	public static void main(String[] args) {

		System.out.println("test start");
		insertProduct("G123458", "갤럭시 폴드4", 1400000, "너무 비싸요~!");
		updateProduct(1);
		deleteProduct("20020");
		searchAll();
	} // end of main
	
	private static void deleteProduct(String productId) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = ConnectionProvider.getConnection();
			String sql = "delete from product where product_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, productId);
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt + "row(s) affected.");
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			CloseUtil.close(con, pstmt);
		}
	}
	private static void updateProduct(int idx) {
		Connection con = null;
		PreparedStatement pstmt = null;
		
		try {
			con = ConnectionProvider.getConnection();
			String sql = "update product\r\n" + 
					"set product_price = 3000000\r\n" + 
					"where idx = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, idx);
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt + "row(s) affected.");
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			CloseUtil.close(con, pstmt);
		}
	}

	private static void insertProduct(String id, String name, int price, String desc) {
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = ConnectionProvider.getConnection();
			// con.setAutoCommit(false);
			String sql = "insert into product (product_id, product_name, product_price, product_desc) values(?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, id);
			pstmt.setString(2, name);
			pstmt.setInt(3, price);
			pstmt.setString(4, desc);
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt + "row(s) affected");
			// con.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(con, pstmt);
		}
	}

	private static void searchAll() {

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			con = ConnectionProvider.getConnection();
			stmt = con.createStatement();
			String sql = "select product_name, product_id, product_price, product_desc\r\n"
					+ "	, date_format(register_date, \"%y.%m.%d\") as date_format\r\n" + "from product;";
			rs = stmt.executeQuery(sql);
			System.out.printf("%s\t%s\t%s\t%s\t%10s\n", "상품이름", "상품아이디", "가격", "상세설명", "등록일");
			while (rs.next()) {
				String pname = rs.getString("product_name");
				String pid = rs.getString("product_id");
				int price = rs.getInt("product_price");
				String desc = rs.getString("product_desc");
				String date = rs.getString("date_format");
				System.out.printf("%s\t%s\t%d\t%s\t%s\n", pname, pid, price, desc, date);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(con, stmt, rs);
		}
	}
} // end of class
