package BeanData;

import java.sql.Date;

// DTO : Data Transfer Object
// VO : Value Object

public class ProductDTO {
	private String productId;
	private String productName;
	private int productPrice;
	private String productDesc;
	private Date productDate;
	
	public ProductDTO() {}
	
	public ProductDTO(String productId, String productName, int productPrice, String productDesc) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productDesc = productDesc;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	
	public Date getProductDate() {
		return productDate;
	}

	public void setProductDate(Date productDate) {
		this.productDate = productDate;
	}

	@Override
	public String toString() {
		return String.format("%s\t%s\t%d\t%s\t%s", productId, productName, productPrice, productDesc, productDate);
	}
	
	
}
