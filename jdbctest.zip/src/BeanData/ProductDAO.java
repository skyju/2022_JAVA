package BeanData;

import java.sql.Connection;

// DAO : DataBase Access Object
public interface ProductDAO {
	void selectAll(Connection con);
	void selectById(Connection con, String productId);
	void selectByPrice(Connection con, int limitPrice);
	void deleteByName(Connection con, String productName);
	void updatePrice(Connection con, String productId, int newPrice);
	void register(Connection con, ProductDTO productDto);
}
