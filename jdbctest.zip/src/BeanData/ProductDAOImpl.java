package BeanData;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import jdbctest.util.CloseUtil;

public class ProductDAOImpl implements ProductDAO {

	// Singleton pattern
	private static ProductDAOImpl productDAOImpl;

	private ProductDAOImpl() {
	}

	static public ProductDAOImpl getProductDao() {
		if (productDAOImpl == null) {
			productDAOImpl = new ProductDAOImpl();
		}
		return productDAOImpl;
	}

	@Override
	public void selectAll(Connection con) {
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "select * from product";
		try {
			stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
			System.out.printf("%s\t%10s\t%s\t%s\t%10s\t%10s\n", "인덱스", "상품이름", "상품아이디", "가격", "상세설명", "등록일");
			while (rs.next()) {
				int idx = rs.getInt("idx");
				String pname = rs.getString("product_name");
				String pid = rs.getString("product_id");
				int price = rs.getInt("product_price");
				String desc = rs.getString("product_desc");
				Date date = rs.getDate("register_date");
				SimpleDateFormat sdf = new SimpleDateFormat("yy.mm.dd");
				System.out.printf("%d\t%s\t%s\t%d\t%s\t%s\n", idx, pname, pid, price, desc, sdf.format(date));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void selectById(Connection con, String productId) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from product where product_id = ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, productId);
			rs = pstmt.executeQuery();
			System.out.printf("%s\t%s\t%s\t%s\t%10s\t%10s\n", "인덱스", "상품이름", "상품아이디", "가격", "상세설명", "등록일");
			while (rs.next()) {
				int idx = rs.getInt("idx");
				String pname = rs.getString("product_name");
				String pid = rs.getString("product_id");
				int price = rs.getInt("product_price");
				String desc = rs.getString("product_desc");
				Date date = rs.getDate("register_date");
				SimpleDateFormat sdf = new SimpleDateFormat("yy.mm.dd");
				System.out.printf("%d\t%s\t%s\t%d\t%s\t%s\n", idx, pname, pid, price, desc, sdf.format(date));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void selectByPrice(Connection con, int limitPrice) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from product where product_price >= ?";
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, limitPrice);
			rs = pstmt.executeQuery();
			System.out.printf("%s\t%s\t%s\t%s\t%s\t%10s\n", "인덱스", "상품이름", "상품아이디", "가격", "상세설명", "등록일");
			while (rs.next()) {
				int idx = rs.getInt("idx");
				String pname = rs.getString("product_name");
				String pid = rs.getString("product_id");
				int price = rs.getInt("product_price");
				String desc = rs.getString("product_desc");
				Date date = rs.getDate("register_date");
				SimpleDateFormat sdf = new SimpleDateFormat("yy.mm.dd");
				System.out.printf("%d\t%s\t%s\t%d\t%s\t%s\n", idx, pname, pid, price, desc, sdf.format(date));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	// delete
	@Override
	public void deleteByName(Connection con, String productName) {
		PreparedStatement pstmt = null;
		try {
			String sql = "delete from product where product_Name = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, productName);
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt + "row(s) affected.");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
		}
	}
	
	// update
	@Override
	public void updatePrice(Connection con, String productId, int newPrice) {
		PreparedStatement pstmt = null;
		try {
			String sql = "update product set product_price = ? where product_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, productId);
			pstmt.setInt(2, newPrice);
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt + "row(s) affected.");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
		}
	}

	// insert
	@Override
	public void register(Connection con, ProductDTO productDto) {
		PreparedStatement pstmt = null;
		try {
			String sql = "insert into product (product_id, product_name, product_price, product_desc) values(?, ?, ?, ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, productDto.getProductId());
			pstmt.setString(2, productDto.getProductName());
			pstmt.setInt(3, productDto.getProductPrice());
			pstmt.setString(4, productDto.getProductDesc());
			int cnt = pstmt.executeUpdate();
			System.out.println(cnt + "row(s) affected.");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			CloseUtil.close(pstmt);
		}
	}

}
